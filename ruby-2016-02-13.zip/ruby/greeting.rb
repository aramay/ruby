def greeting(x = "name")
	return "greetings #{x}"
	
end


text = greeting()
print text

