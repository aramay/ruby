i = 0
until i == 5
	puts i
	i += 1
end
