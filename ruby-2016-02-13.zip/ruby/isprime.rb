def is_prime(x)
	puts "#{x} is not a number" unless x.is_a? Integer
	
end

#is_prime("x")	
is_prime(2)