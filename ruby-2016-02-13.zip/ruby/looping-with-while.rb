require 'pry'

i = 1
binding.pry
while i <= 50 do
	puts i
	i += 1
end



